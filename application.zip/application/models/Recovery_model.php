<?php
class recovery_model extends CI_Model
{

    public function SendRecovery($user_email, $user_token) {

        return true;

    }

   

}
?>